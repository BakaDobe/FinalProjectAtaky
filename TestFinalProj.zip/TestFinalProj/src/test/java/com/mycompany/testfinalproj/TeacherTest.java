/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.testfinalproj;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author ibrah_cfuwhor
 */
public class TeacherTest {
    
    public TeacherTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of setSpeciality method, of class Teacher.
     */
//    @Test
//    public void testSetSpeciality() {
//        System.out.println("setSpeciality");
//        String speciality = "";
//        Teacher instance = new Teacher();
//        instance.setSpeciality(speciality);
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of setDegree method, of class Teacher.
//     */
//    @Test
//    public void testSetDegree() {
//        System.out.println("setDegree");
//        String degree = "";
//        Teacher instance = new Teacher();
//        instance.setDegree(degree);
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of getSpeciality method, of class Teacher.
//     */
//    @Test
//    public void testGetSpeciality() {
//        System.out.println("getSpeciality");
//        Teacher instance = new Teacher();
//        String expResult = "";
//        String result = instance.getSpeciality();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of getDegree method, of class Teacher.
//     */
//    @Test
//    public void testGetDegree() {
//        System.out.println("getDegree");
//        Teacher instance = new Teacher();
//        String expResult = "";
//        String result = instance.getDegree();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }

    /**
     * Test of computePayRoll method, of class Teacher.
     */
    @Test
    public void testComputePayRoll() {
        System.out.println("computePayRoll");
        double saldegree = 42.0;
        Teacher instance = new Teacher();
        double expResult = 2298.2400000000002;
        double result = instance.computePayRoll(saldegree);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Teacher.
     */
//    @Test
//    public void testToString() {
//        System.out.println("toString");
//        Teacher instance = new Teacher();
//        String expResult = "";
//        String result = instance.toString();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }
    
}
