package com.mycompany.testfinalproj;
public abstract class Person {
    //REMEMBER TO ASK IF THEY'RE SUPPOSED TO BE PRIVATE OR PROTECTED
    protected int id;
    protected String name;
    protected int age;
    protected String gender;

    public void setID(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getID() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }
    
}