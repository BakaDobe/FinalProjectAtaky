/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Source;

import static Source.StaffFXMLController.staList;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Dre
 */
public class StartingFXMLController implements Initializable {
    @FXML
    private TableColumn<Department, Integer> colID;
    @FXML
    private TableColumn<Department, String> colDescription;
    @FXML
    private Button btnTeacher;
    @FXML
    private Button btnStaff;
    @FXML
    private Button btnStudent;
    @FXML
    private Button btnLoad;
    public static ObservableList<Department> depList = FXCollections.observableArrayList();
    @FXML
    private TableView<Department> tvDepartment;
    @FXML
    private TableColumn<Department, Integer> colDean;
    @FXML
    private Button btnDean;
    @FXML
    private TextField tfDean;
    
    //Get Departments
    public void getDepartment(ObservableList<Department> arr){
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        colDean.setCellValueFactory(new PropertyValueFactory<>("dean"));
        tvDepartment.setItems(arr);
    } 
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    //Switch from Department Scene to Teacher Scene
    @FXML
    public void changeSceneTeacher(ActionEvent event) throws IOException{
        Parent teacherListParent = FXMLLoader.load(getClass().getResource("TeacherFXML.fxml"));
        Scene teacherListScene = new Scene(teacherListParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(teacherListScene);
        window.show();
    }
    
    //Switch from Department Scene to Staff Scene
    @FXML
    public void changeSceneStaff(ActionEvent event) throws IOException{
        Parent staffListParent = FXMLLoader.load(getClass().getResource("StaffFXML.fxml"));
        Scene staffListScene = new Scene(staffListParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(staffListScene);
        window.show();
    }
    
    //Switch from Department Scene to Student Scene
    @FXML
    public void changeSceneStudent(ActionEvent event) throws IOException{
        Parent studentListParent = FXMLLoader.load(getClass().getResource("FXML.fxml"));
        Scene studentListScene = new Scene(studentListParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(studentListScene);
        window.show();
    }
    
     //Assigning methods to Buttons for functionality 
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        if(event.getSource()==btnLoad){initializeDepartment(depList);}
        if(event.getSource()==btnDean){getDean();}
    }
    
    public void getDean() throws IOException{
        List<Department> DpList = new ArrayList<>(); 
        List<Teacher> TcList = new ArrayList<>(); 
        for(Department d: DpList){
            for(int t = 0; t < TcList.size(); t++){
                if(TcList.get(t).getId() == Integer.parseInt(tfDean.getText())){
                    d.setDean(TcList.get(t));
                }else{
                    throw new IOException("ID does not exist in the list of Teachers");
                }
            }
        }
    }
    
    //Loading predetermined Department with "Load" button
    public void initializeDepartment(ObservableList<Department> arr){
        Department a = new Department(1001, "Exact Sciences");
        Department b = new Department(1003, "Humanities");
        Department c = new Department(1004, "Social Sciences");
        depList.add(a);
        depList.add(b);
        depList.add(c);
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        //colDean.setCellValueFactory(new PropertyValueFactory<>("dean"));
        tvDepartment.setItems(arr);
   }
}
