/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Source;

import static Source.StaffFXMLController.staList;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Dre
 */
public class StartingFXMLController implements Initializable {

    private TextField tfID;
    private TextField tfDescription;
    @FXML
    private TableColumn<Department, Integer> colID;
    @FXML
    private TableColumn<Department, String> colDescription;
    @FXML
    private Button btnTeacher;
    @FXML
    private Button btnStaff;
    @FXML
    private Button btnStudent;
    @FXML
    private Button btnLoad;
    public static ObservableList<Department> depList = FXCollections.observableArrayList();
    @FXML
    private TableView<Department> tvDepartment;
    
    public void getDepartment(ObservableList<Department> arr){
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        tvDepartment.setItems(arr);
    }
    
    public void getDepList(){
        Department s = new Department(Integer.parseInt(tfID.getText()), 
                tfDescription.getText());
        depList.add(s);
    }
    
    boolean temp = true;
    public void saveDep(){
        getDepList();
        getDepartment(depList);
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    public void changeSceneTeacher(ActionEvent event) throws IOException{
        Parent teacherListParent = FXMLLoader.load(getClass().getResource("TeacherFXML.fxml"));
        Scene teacherListScene = new Scene(teacherListParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(teacherListScene);
        window.show();
    }
    
    @FXML
    public void changeSceneStaff(ActionEvent event) throws IOException{
        Parent staffListParent = FXMLLoader.load(getClass().getResource("StaffFXML.fxml"));
        Scene staffListScene = new Scene(staffListParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(staffListScene);
        window.show();
    }
    
    @FXML
    public void changeSceneStudent(ActionEvent event) throws IOException{
        Parent studentListParent = FXMLLoader.load(getClass().getResource("FXML.fxml"));
        Scene studentListScene = new Scene(studentListParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(studentListScene);
        window.show();
    }
    
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        if(event.getSource()==btnLoad){initializeDepartment(depList);}
    }
    
    public void initializeDepartment(ObservableList<Department> arr){
//        Student a = new Student(111, "Dictionary", "Einstein", 1500, 9000);
//        Student c = new Student(222, "Bescherelle", "Newton", 1350, 5000);
//        Student d = new Student(333, "Thesaurus", "Franklin", 1425, 3500);
//        studList.add(a);
//        studList.add(c);
//        studList.add(d);
//        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
//        colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
//        colAuthor.setCellValueFactory(new PropertyValueFactory<>("author"));
//        colYear.setCellValueFactory(new PropertyValueFactory<>("year"));
//        colPages.setCellValueFactory(new PropertyValueFactory<>("pages"));
//        tvBooks.setItems(arr);
//        btnDelete.setDisable(true);
//        btnUpdate.setDisable(true);
   }
}
