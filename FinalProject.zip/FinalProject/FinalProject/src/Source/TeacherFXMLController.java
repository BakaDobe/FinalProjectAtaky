/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Source;

import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author Dre
 */
public class TeacherFXMLController implements Initializable {

    @FXML
    private TextField tfID;
    @FXML
    private TextField tfName;
    @FXML
    private TextField tfAge;
    @FXML
    private TextField tfGender;
    @FXML
    private TextField tfSpeciality;
    @FXML
    private TextField tfDegree;
    @FXML
    private TableView<Teacher> tvTeacher;
    @FXML
    private TableColumn<Teacher, Integer> colID;
    @FXML
    private TableColumn<Teacher, String> colName;
    @FXML
    private TableColumn<Teacher, Integer> colAge;
    @FXML
    private TableColumn<Teacher, String> colGender;
    @FXML
    private TableColumn<Teacher, String> colSpeciality;
    @FXML
    private TableColumn<Teacher, String> colDegree;
    @FXML
    private Button btnInsert;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;
    @FXML
    private Button btnSearch;
    @FXML
    private Button btnLoad;
    public static ObservableList<Teacher> teaList = FXCollections.observableArrayList();
    
    public void getTeacher(ObservableList<Teacher> arr){
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAge.setCellValueFactory(new PropertyValueFactory<>("age"));
        colGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colSpeciality.setCellValueFactory(new PropertyValueFactory<>("speciality"));
        colDegree.setCellValueFactory(new PropertyValueFactory<>("degree"));
        tvTeacher.setItems(arr);
    }
    
    public void getTeacherList(){
        Teacher s = new Teacher(Integer.parseInt(tfID.getText()), 
                tfName.getText(), Integer.parseInt(tfAge.getText()),
                tfGender.getText(), tfSpeciality.getText(),tfDegree.getText());
        teaList.add(s);
    }
    
    boolean temp = true;
    public void saveTeacher(){
        getTeacherList();
        getTeacher(teaList);
        btnSearch.setDisable(false);
    }
    
    public void remTeacher(){
        for(int i = 0; i < teaList.size(); i++){
            if(teaList.get(i).getId()==Integer.parseInt(tfID.getText())){
                teaList.remove(i);
            }
        }
    }
    
    public void upTeacher(){
        Teacher st = new Teacher(Integer.parseInt(tfID.getText()), 
                tfName.getText(), Integer.parseInt(tfAge.getText()),
                tfGender.getText(), tfSpeciality.getText(),
                tfDegree.getText());
        for(int i = 0; i < teaList.size(); i++){
            if(teaList.get(i).getId()==Integer.parseInt(tfID.getText())){
                teaList.set(i, st);
            }
        }
    }
    
    public void searchTeacher(){
        Teacher ss = new Teacher();
        for(int i = 0; i < teaList.size(); i++){
            if(teaList.get(i).getId()== Integer.parseInt(tfID.getText())){
                ss.setId(teaList.get(i).getId());
                ss.setName(teaList.get(i).getName());
                ss.setAge(teaList.get(i).getAge());
                ss.setGender(teaList.get(i).getGender());
                ss.setSpeciality(teaList.get(i).getSpeciality());
                ss.setDegree(teaList.get(i).getDegree());
            }    
        }
        if(ss.getId()!=0){
                tfID.setText(Integer.toString(ss.getId()));
                tfName.setText(ss.getName());
                tfAge.setText(Integer.toString(ss.getAge()));
                tfGender.setText(ss.getGender());
                tfSpeciality.setText(ss.getSpeciality());
                tfDegree.setText(ss.getDegree());
            }
            else{
                System.out.println("Object Not Found");
            }
            btnDelete.setDisable(false);
            btnUpdate.setDisable(false);       
    }
    
    public void searchTeacherIterator(){
        Teacher ss = new Teacher();
        Teacher currentObj = new Teacher();
        Iterator<Teacher> iterator = teaList.iterator();
        
        while(iterator.hasNext()){
            currentObj = iterator.next();
            System.out.println(currentObj);
            if(currentObj.getId()== Integer.parseInt(tfID.getText())){
                ss.setId(currentObj.getId());
                ss.setName(currentObj.getName());
                ss.setAge(currentObj.getAge());
                ss.setGender(currentObj.getGender());
                ss.setSpeciality(currentObj.getSpeciality());
                ss.setDegree(currentObj.getDegree());
            }
        }    
            if(ss.getId()!=0){
                tfID.setText(Integer.toString(ss.getId()));
                tfName.setText(ss.getName());
                tfAge.setText(Integer.toString(ss.getAge()));
                tfGender.setText(ss.getGender());
                tfSpeciality.setText(ss.getSpeciality());
                tfDegree.setText(ss.getDegree());
            }
            else{
                System.out.println("Object Not Found");
            }
            btnDelete.setDisable(false);
            btnUpdate.setDisable(false);
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleButtonAction(ActionEvent event) {
        if(event.getSource()==btnInsert){saveTeacher();}
        if(event.getSource()==btnDelete){remTeacher();}
        if(event.getSource()==btnUpdate){upTeacher();}
        if(event.getSource()==btnSearch){searchTeacherIterator();}
        //if(event.getSource()==btnLoad){initializeBooks(studList);}
    }
    
}
