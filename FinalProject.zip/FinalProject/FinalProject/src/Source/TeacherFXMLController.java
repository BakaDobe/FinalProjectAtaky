/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Source;

import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Dre
 */
public class TeacherFXMLController implements Initializable {

    @FXML
    private TextField tfID;
    @FXML
    private TextField tfName;
    @FXML
    private TextField tfAge;
    @FXML
    private TextField tfGender;
    private TextField tfSpeciality;
    @FXML
    private TextField tfDegree;
    @FXML
    private TableView<Teacher> tvTeacher;
    @FXML
    private TableColumn<Teacher, Integer> colID;
    @FXML
    private TableColumn<Teacher, String> colName;
    @FXML
    private TableColumn<Teacher, Integer> colAge;
    @FXML
    private TableColumn<Teacher, String> colGender;
    @FXML
    private TableColumn<Teacher, String> colSpeciality;
    @FXML
    private TableColumn<Teacher, String> colDegree;
    @FXML
    private Button btnInsert;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;
    @FXML
    private Button btnSearch;
    @FXML
    private Button btnLoad;
    public static ObservableList<Teacher> teaList = FXCollections.observableArrayList();
    @FXML
    private TextField thSpeciality;
    @FXML
    private Button btnStudent;
    @FXML
    private Button btnStaff;
    
    //Get Teachers
    public void getTeacher(ObservableList<Teacher> arr){
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAge.setCellValueFactory(new PropertyValueFactory<>("age"));
        colGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colSpeciality.setCellValueFactory(new PropertyValueFactory<>("speciality"));
        colDegree.setCellValueFactory(new PropertyValueFactory<>("degree"));
        tvTeacher.setItems(arr);
    }
    
    //Get the Teacher list
    public void getTeacherList(){
        Teacher s = new Teacher(Integer.parseInt(tfID.getText()), 
                tfName.getText(), Integer.parseInt(tfAge.getText()),
                tfGender.getText(), tfSpeciality.getText(),tfDegree.getText());
        teaList.add(s);
    }
    
    boolean temp = true;
    public void saveTeacher(){
        getTeacherList();
        getTeacher(teaList);
        btnSearch.setDisable(false);
    }
    
    //Removing Teacher based on ID
    public void remTeacher(){
        for(int i = 0; i < teaList.size(); i++){
            if(teaList.get(i).getId()==Integer.parseInt(tfID.getText())){
                teaList.remove(i);
            }
        }
    }
    
    //Updating Teacher's Information based on ID
    public void upTeacher(){
        Teacher st = new Teacher(Integer.parseInt(tfID.getText()), 
                tfName.getText(), Integer.parseInt(tfAge.getText()),
                tfGender.getText(), tfSpeciality.getText(),
                tfDegree.getText());
        for(int i = 0; i < teaList.size(); i++){
            if(teaList.get(i).getId()==Integer.parseInt(tfID.getText())){
                teaList.set(i, st);
            }
        }
    }
    
    //Search for a Teacher based on their ID
    public void searchTeacher(){
        Teacher ss = new Teacher();
        for(int i = 0; i < teaList.size(); i++){
            if(teaList.get(i).getId()== Integer.parseInt(tfID.getText())){
                ss.setId(teaList.get(i).getId());
                ss.setName(teaList.get(i).getName());
                ss.setAge(teaList.get(i).getAge());
                ss.setGender(teaList.get(i).getGender());
                ss.setSpeciality(teaList.get(i).getSpeciality());
                ss.setDegree(teaList.get(i).getDegree());
            }    
        }
        if(ss.getId()!=0){
                tfID.setText(Integer.toString(ss.getId()));
                tfName.setText(ss.getName());
                tfAge.setText(Integer.toString(ss.getAge()));
                tfGender.setText(ss.getGender());
                tfSpeciality.setText(ss.getSpeciality());
                tfDegree.setText(ss.getDegree());
            }
            else{
                System.out.println("Object Not Found");
            }
            btnDelete.setDisable(false);
            btnUpdate.setDisable(false);       
    }
    
    //Search for a Teacher based on their ID
    public void searchTeacherIterator(){
        Teacher ss = new Teacher();
        Teacher currentObj = new Teacher();
        Iterator<Teacher> iterator = teaList.iterator();
        
        while(iterator.hasNext()){
            currentObj = iterator.next();
            System.out.println(currentObj);
            if(currentObj.getId()== Integer.parseInt(tfID.getText())){
                ss.setId(currentObj.getId());
                ss.setName(currentObj.getName());
                ss.setAge(currentObj.getAge());
                ss.setGender(currentObj.getGender());
                ss.setSpeciality(currentObj.getSpeciality());
                ss.setDegree(currentObj.getDegree());
            }
        }    
            if(ss.getId()!=0){
                tfID.setText(Integer.toString(ss.getId()));
                tfName.setText(ss.getName());
                tfAge.setText(Integer.toString(ss.getAge()));
                tfGender.setText(ss.getGender());
                tfSpeciality.setText(ss.getSpeciality());
                tfDegree.setText(ss.getDegree());
            }
            else{
                System.out.println("Object Not Found");
            }
            btnDelete.setDisable(false);
            btnUpdate.setDisable(false);
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    //Switch from Teacher Scene to Staff Scene
    @FXML
    public void changeSceneStaff(ActionEvent event) throws IOException{
        Parent staffListParent = FXMLLoader.load(getClass().getResource("StaffFXML.fxml"));
        Scene staffListScene = new Scene(staffListParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(staffListScene);
        window.show();
    }
    
    //Switch from Teacher Scene to Student Scene
    @FXML
    public void changeSceneStudent(ActionEvent event) throws IOException{
        Parent studentListParent = FXMLLoader.load(getClass().getResource("FXML.fxml"));
        Scene studentListScene = new Scene(studentListParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(studentListScene);
        window.show();
    }
    
    //Assigning methods to Buttons for functionality 
    @FXML
    private void handleButtonAction(ActionEvent event) {
        if(event.getSource()==btnInsert){saveTeacher();}
        if(event.getSource()==btnDelete){remTeacher();}
        if(event.getSource()==btnUpdate){upTeacher();}
        if(event.getSource()==btnSearch){searchTeacherIterator();}
        //if(event.getSource()==btnLoad){initializeBooks(studList);}
    }
  
}
