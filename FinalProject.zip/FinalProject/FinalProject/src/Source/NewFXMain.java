/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package Source;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Dre
 */
public class NewFXMain extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("StartingFXML.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List<Department> DpList = new ArrayList<>(); 
        List<Teacher> TcList = new ArrayList<>(); 
        List<Staff> SfList = new ArrayList<>(); 
        List<Student> SdList = new ArrayList<>(); 
        launch(args);
    }
    
}
