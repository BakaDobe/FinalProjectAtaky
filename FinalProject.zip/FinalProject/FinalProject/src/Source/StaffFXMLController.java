/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Source;

import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author Dre
 */
public class StaffFXMLController implements Initializable {

    @FXML
    private TextField tfID;
    @FXML
    private TextField tfName;
    @FXML
    private TextField tfAge;
    @FXML
    private TextField tfGender;
    @FXML
    private TextField tfDuty;
    @FXML
    private TextField tfWorkload;
    @FXML
    private TableView<Staff> tvStaff;
    @FXML
    private TableColumn<Staff, Integer> colID;
    @FXML
    private TableColumn<Staff, String> colName;
    @FXML
    private TableColumn<Staff, Integer> colAge;
    @FXML
    private TableColumn<Staff, String> colGender;
    @FXML
    private TableColumn<Staff, String> colDuty;
    @FXML
    private TableColumn<Staff, Integer> colWorkload;
    @FXML
    private Button btnInsert;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;
    @FXML
    private Button btnSearch;
    @FXML
    private Button btnLoad;
    public static ObservableList<Staff> staList = FXCollections.observableArrayList();
    
    public void getStaff(ObservableList<Staff> arr){
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAge.setCellValueFactory(new PropertyValueFactory<>("age"));
        colGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colDuty.setCellValueFactory(new PropertyValueFactory<>("duty"));
        colWorkload.setCellValueFactory(new PropertyValueFactory<>("workload"));
        tvStaff.setItems(arr);
    }
    
    public void getStaList(){
        Staff s = new Staff(Integer.parseInt(tfID.getText()), 
                tfName.getText(), Integer.parseInt(tfAge.getText()),
                tfGender.getText(), tfDuty.getText(),
                Integer.parseInt(tfWorkload.getText()));
        staList.add(s);
    }
    
    boolean temp = true;
    public void saveSta(){
        getStaList();
        getStaff(staList);
        btnSearch.setDisable(false);
    }
    
    public void remSta(){
        for(int i = 0; i < staList.size(); i++){
            if(staList.get(i).getId()==Integer.parseInt(tfID.getText())){
                staList.remove(i);
            }
        }
    }
    
    public void upSta(){
        Staff st = new Staff(Integer.parseInt(tfID.getText()), 
                tfName.getText(), Integer.parseInt(tfAge.getText()),
                tfGender.getText(), tfDuty.getText(),
                Integer.parseInt(tfWorkload.getText()));
        for(int i = 0; i < staList.size(); i++){
            if(staList.get(i).getId()==Integer.parseInt(tfID.getText())){
                staList.set(i, st);
            }
        }
    }
    
    public void searchSta(){
        Staff ss = new Staff();
        for(int i = 0; i < staList.size(); i++){
            if(staList.get(i).getId()== Integer.parseInt(tfID.getText())){
                ss.setId(staList.get(i).getId());
                ss.setName(staList.get(i).getName());
                ss.setAge(staList.get(i).getAge());
                ss.setGender(staList.get(i).getGender());
                ss.setDuty(staList.get(i).getDuty());
                ss.setWorkload(staList.get(i).getWorkload());
            }    
        }
        if(ss.getId()!=0){
                tfID.setText(Integer.toString(ss.getId()));
                tfName.setText(ss.getName());
                tfAge.setText(Integer.toString(ss.getAge()));
                tfGender.setText(ss.getGender());
                tfDuty.setText(ss.getDuty());
                tfWorkload.setText(Integer.toString(ss.getWorkload()));
            }
            else{
                System.out.println("Object Not Found");
            }
            btnDelete.setDisable(false);
            btnUpdate.setDisable(false);       
    }
    
    public void searchStaIterator(){
        Staff ss = new Staff();
        Staff currentObj = new Staff();
        Iterator<Staff> iterator = staList.iterator();
        
        while(iterator.hasNext()){
            currentObj = iterator.next();
            System.out.println(currentObj);
            if(currentObj.getId()== Integer.parseInt(tfID.getText())){
                ss.setId(currentObj.getId());
                ss.setName(currentObj.getName());
                ss.setAge(currentObj.getAge());
                ss.setGender(currentObj.getGender());
                ss.setDuty(currentObj.getDuty());
                ss.setWorkload(currentObj.getWorkload());
            }
        }    
            if(ss.getId()!=0){
                tfID.setText(Integer.toString(ss.getId()));
                tfName.setText(ss.getName());
                tfAge.setText(Integer.toString(ss.getAge()));
                tfGender.setText(ss.getGender());
                tfDuty.setText(ss.getDuty());
                tfWorkload.setText(Integer.toString(ss.getWorkload()));
            }
            else{
                System.out.println("Object Not Found");
            }
            btnDelete.setDisable(false);
            btnUpdate.setDisable(false);
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleButtonAction(ActionEvent event) {
        if(event.getSource()==btnInsert){saveSta();}
        if(event.getSource()==btnDelete){remSta();}
        if(event.getSource()==btnUpdate){upSta();}
        if(event.getSource()==btnSearch){searchStaIterator();}
        //if(event.getSource()==btnLoad){initializeBooks(studList);}
    }
    
}
