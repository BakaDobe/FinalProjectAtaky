/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Source;

import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Dre
 */
public class StaffFXMLController implements Initializable {

    @FXML
    private TextField tfID;
    @FXML
    private TextField tfName;
    @FXML
    private TextField tfAge;
    @FXML
    private TextField tfGender;
    @FXML
    private TextField tfDuty;
    @FXML
    private TextField tfWorkload;
    @FXML
    private TableView<Staff> tvStaff;
    @FXML
    private TableColumn<Staff, Integer> colID;
    @FXML
    private TableColumn<Staff, String> colName;
    @FXML
    private TableColumn<Staff, Integer> colAge;
    @FXML
    private TableColumn<Staff, String> colGender;
    @FXML
    private TableColumn<Staff, String> colDuty;
    @FXML
    private TableColumn<Staff, Integer> colWorkload;
    @FXML
    private Button btnInsert;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;
    @FXML
    private Button btnSearch;
    @FXML
    private Button btnLoad;
    public static ObservableList<Staff> staList = FXCollections.observableArrayList();
    @FXML
    private Button btnTeacher;
    @FXML
    private Button btnStudent;
    
    //Get Staff
    public void getStaff(ObservableList<Staff> arr){
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAge.setCellValueFactory(new PropertyValueFactory<>("age"));
        colGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colDuty.setCellValueFactory(new PropertyValueFactory<>("duty"));
        colWorkload.setCellValueFactory(new PropertyValueFactory<>("workload"));
        tvStaff.setItems(arr);
    }
    
    //Get the Staff list
    public void getStaList(){
        Staff s = new Staff(Integer.parseInt(tfID.getText()), 
                tfName.getText(), Integer.parseInt(tfAge.getText()),
                tfGender.getText(), tfDuty.getText(),
                Integer.parseInt(tfWorkload.getText()));
        staList.add(s);
    }
    
    boolean temp = true;
    public void saveSta(){
        getStaList();
        getStaff(staList);
        btnSearch.setDisable(false);
    }
    
    //Removing Staff based on ID
    public void remSta(){
        for(int i = 0; i < staList.size(); i++){
            if(staList.get(i).getId()==Integer.parseInt(tfID.getText())){
                staList.remove(i);
            }
        }
    }
    
    //Updating Staff's Information based on ID
    public void upSta(){
        Staff st = new Staff(Integer.parseInt(tfID.getText()), 
                tfName.getText(), Integer.parseInt(tfAge.getText()),
                tfGender.getText(), tfDuty.getText(),
                Integer.parseInt(tfWorkload.getText()));
        for(int i = 0; i < staList.size(); i++){
            if(staList.get(i).getId()==Integer.parseInt(tfID.getText())){
                staList.set(i, st);
            }
        }
    }
    
    //Search for a Staff based on their ID
    public void searchSta(){
        Staff ss = new Staff();
        for(int i = 0; i < staList.size(); i++){
            if(staList.get(i).getId()== Integer.parseInt(tfID.getText())){
                ss.setId(staList.get(i).getId());
                ss.setName(staList.get(i).getName());
                ss.setAge(staList.get(i).getAge());
                ss.setGender(staList.get(i).getGender());
                ss.setDuty(staList.get(i).getDuty());
                ss.setWorkload(staList.get(i).getWorkload());
            }    
        }
        if(ss.getId()!=0){
                tfID.setText(Integer.toString(ss.getId()));
                tfName.setText(ss.getName());
                tfAge.setText(Integer.toString(ss.getAge()));
                tfGender.setText(ss.getGender());
                tfDuty.setText(ss.getDuty());
                tfWorkload.setText(Integer.toString(ss.getWorkload()));
            }
            else{
                System.out.println("Object Not Found");
            }
            btnDelete.setDisable(false);
            btnUpdate.setDisable(false);       
    }
    
    //Search for a Staff based on their ID
    public void searchStaIterator(){
        Staff ss = new Staff();
        Staff currentObj = new Staff();
        Iterator<Staff> iterator = staList.iterator();
        
        while(iterator.hasNext()){
            currentObj = iterator.next();
            System.out.println(currentObj);
            if(currentObj.getId()== Integer.parseInt(tfID.getText())){
                ss.setId(currentObj.getId());
                ss.setName(currentObj.getName());
                ss.setAge(currentObj.getAge());
                ss.setGender(currentObj.getGender());
                ss.setDuty(currentObj.getDuty());
                ss.setWorkload(currentObj.getWorkload());
            }
        }    
            if(ss.getId()!=0){
                tfID.setText(Integer.toString(ss.getId()));
                tfName.setText(ss.getName());
                tfAge.setText(Integer.toString(ss.getAge()));
                tfGender.setText(ss.getGender());
                tfDuty.setText(ss.getDuty());
                tfWorkload.setText(Integer.toString(ss.getWorkload()));
            }
            else{
                System.out.println("Object Not Found");
            }
            btnDelete.setDisable(false);
            btnUpdate.setDisable(false);
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    //Switch from Staff Scene to Teacher Scene
    @FXML
    public void changeSceneTeacher(ActionEvent event) throws IOException{
        Parent teacherListParent = FXMLLoader.load(getClass().getResource("TeacherFXML.fxml"));
        Scene teacherListScene = new Scene(teacherListParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(teacherListScene);
        window.show();
    }
    
    //Switch from Staff Scene to Student Scene
    @FXML
    public void changeSceneStudent(ActionEvent event) throws IOException{
        Parent studentListParent = FXMLLoader.load(getClass().getResource("FXML.fxml"));
        Scene studentListScene = new Scene(studentListParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(studentListScene);
        window.show();
    }
    
    //Assigning methods to Buttons for functionality 
    @FXML
    private void handleButtonAction(ActionEvent event) {
        if(event.getSource()==btnInsert){saveSta();}
        if(event.getSource()==btnDelete){remSta();}
        if(event.getSource()==btnUpdate){upSta();}
        if(event.getSource()==btnSearch){searchStaIterator();}
        //if(event.getSource()==btnLoad){initializeBooks(studList);}
    }
    
}
