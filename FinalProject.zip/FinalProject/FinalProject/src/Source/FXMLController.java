/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Source;

import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author Dre
 */
public class FXMLController implements Initializable {

    @FXML
    private TextField tfID;
    @FXML
    private TextField tfName;
    @FXML
    private TextField tfAge;
    @FXML
    private TextField tfGender;
    @FXML
    private TextField tfCourse;
    @FXML
    private TextField tfSemester;
    @FXML
    private TableColumn<Student, Integer> colID;
    @FXML
    private TableColumn<Student, String> colName;
    @FXML
    private TableColumn<Student, Integer> colAge;
    @FXML
    private TableColumn<Student, String> colGender;
    @FXML
    private TableColumn<Student, String> colCourse;
    @FXML
    private TableColumn<Student, Integer> colSemester;
    @FXML
    private TableView<Student> tvStudent;
    @FXML
    private Button btnInsert;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;
    @FXML
    private Button btnSearch;
    @FXML
    private Button btnLoad;
    public static ObservableList<Student> studList = FXCollections.observableArrayList();
    
    public void getStudent(ObservableList<Student> arr){
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAge.setCellValueFactory(new PropertyValueFactory<>("age"));
        colGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colCourse.setCellValueFactory(new PropertyValueFactory<>("course"));
        colSemester.setCellValueFactory(new PropertyValueFactory<>("semester"));
        tvStudent.setItems(arr);
    }
    
    public void getStudList(){
        Student s = new Student(Integer.parseInt(tfID.getText()), 
                tfName.getText(), Integer.parseInt(tfAge.getText()),
                tfGender.getText(), tfCourse.getText(),
                Integer.parseInt(tfSemester.getText()));
        studList.add(s);
    }
    
    boolean temp = true;
    public void saveStud(){
        getStudList();
        getStudent(studList);
        btnSearch.setDisable(false);
    }
    
    public void remStud(){
        for(int i = 0; i < studList.size(); i++){
            if(studList.get(i).getId()==Integer.parseInt(tfID.getText())){
                studList.remove(i);
            }
        }
    }
    
    public void upStud(){
        Student st = new Student(Integer.parseInt(tfID.getText()), 
                tfName.getText(), Integer.parseInt(tfAge.getText()),
                tfGender.getText(), tfCourse.getText(),
                Integer.parseInt(tfSemester.getText()));
        for(int i = 0; i < studList.size(); i++){
            if(studList.get(i).getId()==Integer.parseInt(tfID.getText())){
                studList.set(i, st);
            }
        }
    }
    
    public void searchStud(){
        Student ss = new Student();
        for(int i = 0; i < studList.size(); i++){
            if(studList.get(i).getId()== Integer.parseInt(tfID.getText())){
                ss.setId(studList.get(i).getId());
                ss.setName(studList.get(i).getName());
                ss.setAge(studList.get(i).getAge());
                ss.setGender(studList.get(i).getGender());
                ss.setCourse(studList.get(i).getCourse());
                ss.setSemester(studList.get(i).getSemester());
            }    
        }
        if(ss.getId()!=0){
                tfID.setText(Integer.toString(ss.getId()));
                tfName.setText(ss.getName());
                tfAge.setText(Integer.toString(ss.getAge()));
                tfGender.setText(ss.getGender());
                tfCourse.setText(ss.getCourse());
                tfSemester.setText(Integer.toString(ss.getSemester()));
            }
            else{
                System.out.println("Object Not Found");
            }
            btnDelete.setDisable(false);
            btnUpdate.setDisable(false);       
    }
    
    public void searchStudIterator(){
        Student ss = new Student();
        Student currentObj = new Student();
        Iterator<Student> iterator = studList.iterator();
        
        while(iterator.hasNext()){
            currentObj = iterator.next();
            System.out.println(currentObj);
            if(currentObj.getId()== Integer.parseInt(tfID.getText())){
                ss.setId(currentObj.getId());
                ss.setName(currentObj.getName());
                ss.setAge(currentObj.getAge());
                ss.setGender(currentObj.getGender());
                ss.setCourse(currentObj.getCourse());
                ss.setSemester(currentObj.getSemester());
            }
        }    
            if(ss.getId()!=0){
                tfID.setText(Integer.toString(ss.getId()));
                tfName.setText(ss.getName());
                tfAge.setText(Integer.toString(ss.getAge()));
                tfGender.setText(ss.getGender());
                tfCourse.setText(ss.getCourse());
                tfSemester.setText(Integer.toString(ss.getSemester()));
            }
            else{
                System.out.println("Object Not Found");
            }
            btnDelete.setDisable(false);
            btnUpdate.setDisable(false);
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleButtonAction(ActionEvent event) {
        if(event.getSource()==btnInsert){saveStud();}
        if(event.getSource()==btnDelete){remStud();}
        if(event.getSource()==btnUpdate){upStud();}
        if(event.getSource()==btnSearch){searchStudIterator();}
        //if(event.getSource()==btnLoad){initializeBooks(studList);}
    }
    
//    public void initializeBooks(ObservableList<Student> arr){
//        Student a = new Student(111, "Dictionary", "Einstein", 1500, 9000);
//        Student c = new Student(222, "Bescherelle", "Newton", 1350, 5000);
//        Student d = new Student(333, "Thesaurus", "Franklin", 1425, 3500);
//        studList.add(a);
//        studList.add(c);
//        studList.add(d);
//        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
//        colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
//        colAuthor.setCellValueFactory(new PropertyValueFactory<>("author"));
//        colYear.setCellValueFactory(new PropertyValueFactory<>("year"));
//        colPages.setCellValueFactory(new PropertyValueFactory<>("pages"));
//        tvBooks.setItems(arr);
//        btnDelete.setDisable(true);
//        btnUpdate.setDisable(true);
//    }
    
}
